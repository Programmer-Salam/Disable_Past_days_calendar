<html>
    <head>
    <script type="text/javascript" src="csss.css"></script>
</head>
<body>
<form method="POST">
   <input id="date_picker" type="date" name="from"/><br />
  
    <script language="javascript">
        var today = new Date();
        var dd = String(today.getDate()).padStart(2, '0');
        var mm = String(today.getMonth() + 1).padStart(2, '0');
        var yyyy = today.getFullYear();

        today = yyyy + '-' + mm + '-' + dd;
        $('#date_picker').attr('min',today);
    </script>
    <br />
      <input id="date_pickers" type="date" name="to"/>
          <script language="javascript">
        var today = new Date();
        var dd = String(today.getDate()).padStart(2, '0');
        var mm = String(today.getMonth() + 1).padStart(2, '0');
        var yyyy = today.getFullYear();

        today = yyyy + '-' + mm + '-' + dd;
        $('#date_pickers').attr('min',today);
    </script>
    <br />
    <br />
     <input type="submit" name="submit"/>
    </form>
</body>

</html>
<?php
    $conn=mysqli_connect("localhost","root","","hrinformationsystem_db");
if(isset($_POST['submit'])){
    $from=$_POST['from'];
     $to=$_POST['to'];
 
     $update=mysqli_query($conn,"update login set login_date='$from',tooo='$to'");
     if($update){
        echo "<script> alert ('Successful') </script>";
     }else{
            echo "error".mysqli_connect.$conn;
     }
}
?>